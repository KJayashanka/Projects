// new page will be shown exaclty after 4secs
setTimeout(function(){
	window.location.href = 'Home.html';
}, 4000);